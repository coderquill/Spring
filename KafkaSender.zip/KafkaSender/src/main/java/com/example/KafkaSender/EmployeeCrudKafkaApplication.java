package com.example.KafkaSender;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeCrudKafkaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeCrudKafkaApplication.class, args);
	}

}
