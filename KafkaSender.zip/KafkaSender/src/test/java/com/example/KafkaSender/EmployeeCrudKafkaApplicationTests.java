package com.example.KafkaSender;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeCrudKafkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
