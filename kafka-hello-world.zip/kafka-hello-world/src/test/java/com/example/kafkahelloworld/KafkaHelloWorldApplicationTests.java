package com.example.kafkahelloworld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaHelloWorldApplicationTests {

	@Test
	void contextLoads() {
	}

}
